
Space simulation - binary executable
by Megha Sharma

This is a 3d space simulation.  My contribution to this project was the user interface.

To execute this project run "go.bat".

This project depends upon QT4 to run.  This dependency can be satisfied by having QT4 installed, or by unzipping "spacesim_QT_Dlls.zip" into the same directory.
