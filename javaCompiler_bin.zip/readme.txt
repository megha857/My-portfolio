
Java Compiler - Binary executable
by Megha Sharma

Java compiler serves the purpose of "javac" in the java JDK.

This is the binary executable for my Java compiler.

To execute it, run the following from the command line:

bin/bin/j--

This will display help text for j--.
To compile a java file, run the following from the command line:

bin/bin/j-- <FileToCompile.java>

and it will work in a fashion similar to "javac" in the java JDK.
