/*
*   file:   slex.c
*   author: betty o'neil
*   edited by: Megha Sharma
*
*   simple lexical analyzer, front part of a parser                   
*   compare to UNIX tool "lex", general lexical analyzer            
*   gets a (space-delimited) token from linebuf and tries to match    
*   it to one of the cmdtokens in the provided cmdtable             
*
*   accepts:       
*         linebuf: string to get token from                         
*         cmdtable: cmdtable to use                                 
*   returns:                                                          
*         *cnum_ptr: command # (offset in cmdtable) or -1 if no match
*         *pos_ptr: new place in linebuf after token match          
*
*   improvements needed:
*         make token matching case independent
*         skip whitespace, not just blanks
*
*   revisions: 
*     9/90 cleanup, convert function headers to ansi form
*
*/


/* for definition of type cmd */
#include <stdio.h>
#include "slex.h"		

 /* string from user */
 int slex(char *linebuf, 
 /* cmd table to use */
 Cmd cmdtable[],     
 /* returned command number */
 int *cnum_ptr,  
 /* returned new place in linebuf */
 int *pos_ptr      
    ) 
{
  int i = 0;
  char token[MAXTOKENLEN];
  int newpos;
	/* get token from linebuf */
  if (gettoken(linebuf,token,&newpos)<0)
	/* if token cannot be found */
    return -1;			

  while ((cmdtable[i].cmdtoken != NULL)) {
    if (strcmp(cmdtable[i].cmdtoken,token)==0) {
    /* success: return command # */
	*cnum_ptr = i;	
	/* and where we got to in linebuf */	
	*pos_ptr = newpos;	
	return 0;
    }
    else
    /* keep scanning table */
      i++;			
  }
  /* no match */
  return -1;			
}

/*
 * get one space-delimited token from string in linebuf, also return 
 * new position in string 
 */
int gettoken(char *linebuf, char *token, int *pos_ptr)
{
  int i = 0;
  int j = 0;

  while (linebuf[i]==' ')
	  /* skip blanks */
    i++;			
  while (linebuf[i]!=' '&&linebuf[i]!='\0')
	  /* copy chars to token */
    token[j++] = linebuf[i++];	
  if (j==0)
	  /* nothing there */
    return -1;			
  else
    {
	/* null-terminate token */
      token[j] = '\0';	
	  /* return place in linebuf we got to */	
      *pos_ptr = i;	
	  /* success */	
      return 0;			
    }
}
