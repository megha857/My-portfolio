
UART Com port driver - source code (C and assembly)
by Megha Sharma

This is the UART Com port port driver and echo test program that I wrote for a unix kernel.

It is designed to be compiled and run on an i386 computer running the "tutor" operating system.
