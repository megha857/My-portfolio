/*  file:     slex.h
*   author:   Ethan Bolker
*    edited by: Megha Sharma
*   date:     September, 1990
*   header file for lexical analyzer slex.h
*   built from betty o'neil's previous version
*/

 /* label ANSI C function prototypes with empty string */
#ifndef PROTOTYPE
#define PROTOTYPE   
#endif

#define LINELEN 80
#define MAXTOKENLEN 80

/* This typedef takes an object oriented view */

typedef struct cmdtag {
	/* md to invoke cmd */
  char *cmdtoken;		
  /* function to call when the command is seen */
  int (*cmdfn)(struct cmdtag *, char *);  
  /* helpstring for cmd */
  char *help;			
} Cmd;

/* providing space for and contents of the command table. */

extern Cmd cmds[];


/* A function prototype for the lexical analyzer: */

	/* string from user */
	PROTOTYPE int slex(char *linebuf, 
    /* cmd table to use */  
    Cmd cmdtable[],       
	/* returned command number */
    int *cnum_ptr,
	/* returned new place in linebuf */
    int *pos_ptr     
   ) ;

/* A function prototype for gettoken, called by lexical analyzer */

PROTOTYPE int gettoken(char *linebuf, char *token, int *pos_ptr);

/* A function prototype for getcmd, called by tutor main line */

PROTOTYPE void getcmd(char *linebuf, int *cnum_ptr, int *pos_ptr);

