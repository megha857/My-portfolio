/* Megha Sharma
   CS341 mp5 
file name: comintspack.c */


/* package for using com port interrupts */
#include <stdio.h>
#include <serial.h>
#include <pic.h>
#include <cpu.h>
#include "comintspack.h"

/* ascii characters used */
#define CR '\x0d'
#define LF '\x0a'

void irq4inthandc (void);
static void (*this_callback)(char *);
static char *this_buffer;
static int this_size;
static int this_mode;
static int cursor;

/* This assembler routine is supplied in the SAPC library */
/* in irq4.s, calls irq4inthandc */

extern IntHandler irq4inthand;
#define PROMPT "Prompt: \n\r"
void init_comints (int mode, void (*callback)(char *), char *buffer, int size)
{
   /* This function expects to be called with interrupts disabled.
    * It may be called by the background between cli() and sti() calls
    * or by an interrupt service routine (ISR) where interrupts are off.
    * That is why this code does not call cli() or sti() itself.
    */
   int i = 0;
   char *p = PROMPT;
   /* Save the inputs statically for use in the ISR */
   this_callback = callback;
   this_buffer = buffer;
   this_size = size;
   this_mode = mode;
   cursor = 0;

 
   
   /* COM1 uses IRQ 4 */
   /* First drain any input out of the COM1's receiver--a full FIFO */
   /* (multichar buffer in UART) causes this UART to stop interrupting!  */
   
    /* while one there, pull another char out of UART */
   while (inpt(COM1_BASE+UART_LSR)&UART_LSR_DR)
	  inpt(COM1_BASE+UART_RX); 


   /* put irq4inthand in the right place in the IDT */
   
   set_intr_gate(COM1_IRQ + IRQ_TO_INT_N_SHIFT, &irq4inthand);/*added*/

   /* enable interrupts for COM1's IRQ in the PIC */
   
   pic_enable_irq(COM1_IRQ);
   
   if (mode == RECEIVE) {
     /* turn on receiver interrupts in the UART's IER */
	 outpt(COM1_BASE + UART_IER, inpt(COM1_BASE + UART_IER) | UART_IER_RDI);
	 for(i = 0; i < strlen(p);i++)
	   outpt(COM1_BASE,*(p+i));
   }
   else {
     /* turn on transmitter interrupts in the UART's IER */
	 outpt(COM1_BASE + UART_IER, inpt(COM1_BASE + UART_IER) | UART_IER_THRI);
   }
}

void shutdown_comints ()
{
  /* This function expects to be called with interrupts disabled.
   * It may be called by the background between cli() and sti() calls
   * or by an interrupt service routine (ISR) where interrupts are off.
   * That is why this code does not call cli() or sti() itself.
   */


  /* disable COM1's IRQ in the PIC */
  pic_disable_irq(COM1_IRQ);

  /* turn off transmitter and receiver interrupts in COM1's IER */
  outpt(COM1_BASE + UART_IER, ((inpt(COM1_BASE + UART_IER) &(~UART_IER_RDI))&(~UART_IER_THRI)));

}

/* This is called from irq4inthand, the assembler interrupt envelope 
 that routine saves the C compiler scratch registers 
 calls this function to process the interrupt 
 restores the C compiler scratch registers and executes iret */
 
void irq4inthandc(void)
{
  char c;  
  pic_end_int();  
  if (this_mode == RECEIVE) 
  { /* receive interrupt */
	c = inpt(COM1_BASE);
	outpt(COM1_BASE, c);
	this_buffer[cursor] = c;
	cursor++;
	if(c == CR)
	{
	  *(this_buffer+cursor)= '\0';
	  this_callback(this_buffer);
	  outpt(COM1_BASE,LF);		 
	}
  }
  else 
  { /* transmit interrupt */
	c = this_buffer[cursor];
	if(c != '\0')
	{
	  outpt(COM1_BASE, 0);
	  cursor++;
	}
	else
	  this_callback(this_buffer);
  }
                   
}
