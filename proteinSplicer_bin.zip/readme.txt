
Protein splicer - binary executable
by Megha Sharma

This is a protein splicer, written to aid in bioinformatics research.

This java application is to be run by executing the "run.bat" command.

