﻿using System;
using System.Data;
using System.Data.Common;

/// <summary>
/// Summary description for CoralAccess
/// </summary>
public static class CoralAccess
{
	static CoralAccess()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    // Retrieve the list of departments 
    public static DataTable GetRoomsPrices()
    {
        // get a configured DbCommand object
        DbCommand comm = GenericDataAccess.CreateCommand();
        // set the stored procedure name
        comm.CommandText = "GetRoomPrices";
        // execute the stored procedure and return the results
        return GenericDataAccess.ExecuteSelectCommand(comm);
    }
}