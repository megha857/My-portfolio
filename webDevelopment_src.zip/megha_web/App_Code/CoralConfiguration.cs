﻿using System;
using System.Configuration;

/// <summary>
/// Summary description for CoralConfiguration
/// </summary>
public static class CoralConfiguration
{
  // Caches the connection string
  private static string dbConnectionString;
  // Caches the data provider name 
  private static string dbProviderName;

  static CoralConfiguration()
	{
    dbConnectionString = ConfigurationManager.ConnectionStrings["CoralConnection"].ConnectionString;
    dbProviderName = ConfigurationManager.ConnectionStrings["CoralConnection"].ProviderName;
  }

  // Returns the connection string for the BalloonShop database
  public static string DbConnectionString
  {
    get
    {
      return dbConnectionString;
    }
  }

  // Returns the data provider name
  public static string DbProviderName
  {
    get
    {
      return dbProviderName;
    }
  }

  // Returns the address of the mail server
  public static string MailServer
  {
    get
    {
      return ConfigurationManager.AppSettings["MailServer"];
    }
  }

  // Send error log emails?
  public static bool EnableErrorLogEmail
  {
    get
    {
      return bool.Parse(ConfigurationManager.AppSettings["EnableErrorLogEmail"]);
    }
  }

  // Returns the email address where to send error reports
  public static string ErrorLogEmail
  {
    get
    {
      return ConfigurationManager.AppSettings["ErrorLogEmail"];
    }
  }
}