	CREATE DATABASE Coral

	GO

	USE Coral

	GO

	CREATE TABLE RoomPrices(
	    RoomID INT  NOT NULL,
		Name CHAR(3) NOT NULL,
	    Bed INT  NOT NULL,
	    Bath INT  NOT NULL,
	    Rent INT  NOT NULL,
	    Sqft INT  NOT NULL,
		CONSTRAINT PK_RoomPrices PRIMARY KEY CLUSTERED (RoomID ASC)
	)

	GO

	CREATE PROCEDURE GetRoomPrices AS
	SELECT RoomID, Name, Bed, Bath, Rent, Sqft
	FROM RoomPrices

	GO

	INSERT INTO RoomPrices (RoomID, Name, Bed, Bath, Rent, Sqft ) 
	VALUES (1, '10A', 1, 1, 1000, 800)

	GO

	INSERT INTO RoomPrices (RoomID, Name, Bed, Bath, Rent, Sqft )		
	VALUES (2, '3F', 1, 2, 1300, 900)
	GO

	INSERT INTO RoomPrices (RoomID, Name, Bed, Bath, Rent, Sqft )		
	VALUES (3, '14C', 2, 2, 1000, 800)
	GO

	INSERT INTO RoomPrices (RoomID, Name, Bed, Bath, Rent, Sqft ) 
	VALUES (4, '9F', 1, 1, 1000, 800)

	GO

	INSERT INTO RoomPrices (RoomID, Name, Bed, Bath, Rent, Sqft )		
	VALUES (5, '12A', 1, 2, 1300, 900)
	GO

	INSERT INTO RoomPrices (RoomID, Name, Bed, Bath, Rent, Sqft )		
	VALUES (6, '12B', 2, 2, 1000, 800)
	GO

	INSERT INTO RoomPrices (RoomID, Name, Bed, Bath, Rent, Sqft ) 
	VALUES (7, '12C', 1, 1, 1000, 800)

	GO

	INSERT INTO RoomPrices (RoomID, Name, Bed, Bath, Rent, Sqft )		
	VALUES (8, '15A', 1, 2, 1300, 900)
	GO

	INSERT INTO RoomPrices (RoomID, Name, Bed, Bath, Rent, Sqft )		
	VALUES (9, '15B', 2, 2, 1000, 800)
	GO

		INSERT INTO RoomPrices (RoomID, Name, Bed, Bath, Rent, Sqft ) 
	VALUES (10, '15C', 1, 1, 1000, 800)

	GO

	INSERT INTO RoomPrices (RoomID, Name, Bed, Bath, Rent, Sqft )		
	VALUES (11, '21C', 1, 2, 1300, 900)
	GO

	INSERT INTO RoomPrices (RoomID, Name, Bed, Bath, Rent, Sqft )		
	VALUES (12, '21D', 2, 2, 1000, 800)
	GO

