var ptn_fn= /^\s*[A-Za-z]+\S*[a-zA-Z]\s*$/;
var ptn_ln= /^\s*[A-Za-z]+\S*[a-zA-Z]\s*$/;
var phn = /^(\([2-9]\d{2}\)|[2-9]\d{2})[- ]?\d{3}[- ]?\d{4}$/;
var strnu = /^[0-9 _]*[0-9][0-9 _]*$/;
var strna = /^[A-Za-z]*[A-Za-z][A-Za-z]*$/;
var aptn = /^[0-9 _]*[0-9][0-9 _]*$/;
var zc =  /^\d{5}$/;
var account;
var loc;
var piz;
var radio;

function validFName(fName, wrong){
		if (fName.value.match(ptn_fn)){
				getMsg (wrong, "");
				    return true;
					}
             else{
		    getMsg(wrong, "Your first name must start and end with an alphabet");
				   return false;
				}
				}
  function getMsg (wrong, message){
      wrong.innerHTML =  message; 
}
function validLName(lName, wrong){
		if (lName.value.match(ptn_ln)){
				getMsg (wrong, "");
				    return true;
					}
             else{
		    getMsg(wrong, "Your last name must start and end with an alphabet");
				   return false;
				}
				}
  function getMsg (wrong, message){
      wrong.innerHTML =  message; 
}
function phoneNum(pho, wrong){
		if (pho.value.match(phn)){
				getMsg (wrong, "");
				    return true;
					}
             else{
		    getMsg(wrong, "A phone number can only contain digits!");
				   return false;
				}
				}
  function getMsg (wrong, message){
      wrong.innerHTML =  message; 
}
function streetNum(str1, wrong){
		if (str1.value.match(strnu)){
				getMsg (wrong, "");
				    return true;
					}
             else{
		    getMsg(wrong, "A street number can only contain digits!");
				   return false;
				}
				}
  function getMsg (wrong, message){
      wrong.innerHTML =  message; 
}
function streetNam(str2, wrong){
		if (str2.value.match(strna)){
				getMsg (wrong, "");
				    return true;
					}
             else{
		    getMsg(wrong, "A street name can only contain alphabets.");
				   return false;
				}
				}
  function getMsg (wrong, message){
      wrong.innerHTML =  message; 
}
function aptN(apt, wrong){
		if (apt.value.match(aptn)){
				getMsg (wrong, "");
				    return true;
					}
             else{
		    getMsg(wrong, "An apartment number, it can only contain digits!");
				   return false;
				}
				}
  function getMsg (wrong, message){
      wrong.innerHTML =  message; 
}
function zipCode(zC, wrong){
		if (zC.value.match(zc)){
				getMsg (wrong, "");
				    return true;
					}
             else{
		    getMsg(wrong, "The zip code needs to be a number of 5 digits.");
				   return false;
				}
				}
 function getMsg (wrong, message){
      wrong.innerHTML =  message; 
}
function yourReciept(at,first,last,phone,strNu,strNa,apt,state,zipcode,location,topping1,pizzas,wrong,acct,fn,ln,pnum,stnu,stna,apnu,sta,zc,loca,p,quanp){




validFName(first,error1); validLName(last,error2); phoneNum(phone,error3); streetNum(strNu,error4); streetNam(strNa,error5); aptN(apt,error6); zipCode(zipcode,error7);

if (validFName(first,error1) && validLName(last,error2)&& phoneNum(phone,error3)&& streetNum(strNu,error4)&& streetNam(strNa,error5)&& aptN(apt,error6)&& zipCode(zipcode,error7)){

theReciept(wrong, "Thank you for your order, here is your reciept:");
			
			theReciept(acct, "Your Account information is below:");


				account = getCheckedRadio(at);
				account = account ? account.value : undefined;	
				theReciept(acct,  "Account type is: " + account);
				
theReciept(fn,  "First name is: " + first.value); theReciept(ln,  "Last name is: " + last.value); theReciept(pnum,  "Phone Number is: " + phone.value);
theReciept(stnu,  "Street number is: " + strNu.value);   theReciept(stna,  "Street name is: " + strNa.value); 
theReciept(apnu,  "Apartment number is: " + apt.value); theReciept(sta,  "The state is " + state.value); theReciept(zc,  "The zipcode is: " + zipcode.value); 
 
 loc = getCheckedRadio(location);
	loc = loc ? loc.value : undefined;	
        theReciept(loca,  "Your location type is: " + loc );

	
         piz = getCheckedRadio(topping1);
			piz = piz ? piz.value : undefined;	
				theReciept(p, "The topping: " + piz);
				//p.innerHTML = "testing";
	                theReciept(quanp,  "Total pizzas are: " + pizzas.value);	

}
else{
theReciept(wrong, "You've not entered all the required fields, please check and try again!");
theReciept(fn,  ""); theReciept(ln,  ""); theReciept(pnum,  ""); theReciept(stnu,  ""); theReciept(stna,  ""); theReciept(apnu,  ""); 
theReciept(zc,  ""); 
}
}

function theReciept(wrong, message){  
       wrong.innerHTML =  message; 
		}

	function getCheckedRadio(checkButtons) {
    	 for (var i = 0; i < checkButtons.length; i++) {
         radio = checkButtons[i];
         if (radio.checked) {
            return radio;
        }
    }
    return undefined;
}			
				


