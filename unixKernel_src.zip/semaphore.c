/* Megha Sharma */

#include <stdio.h>
#include <cpu.h>
#include <pic.h>
#include <timer.h>
#include "tsystm.h"
#include "proc.h"
#include "sched.h"
#include "debuglog.h"
#include "ttimer.h"
#include "semaphore.h"

int syssem_create(int init_count){
  int i;
  for (i=0;i<ARRAYSIZE;i++){
    if(sarray[i].active!=1)
      sarray[i].active=1;
    sarray[i].count=init_count;
    init_i_queue(&sarray[i].processlist,30);
  }


  return 0;
}

int semsysup(int semid){
  if(sarray[semid].active != 1)
    return -1;
  if(!i_emptyque(&sarray[semid].processlist)){
    kprintf("wake test up");
    twakeup_one(i_dequeue(&sarray[semid].processlist));
    kprintf("wake test up2");
  }else{
    kprintf("wake test up3");
    sarray[semid].count++;
    kprintf("UP");
    kprintf("wake test up4");
  }
  kprintf("wake test up5");
  return 0;
}

int semsysdown(int semid){
  if(sarray[semid].active != 1)
    return -1;
  if(sarray[semid].count == 0){	
    i_enqueue(&sarray[semid].processlist,curproc->pid);	        
    tsleep(TTY0_OUTPUT);
  }else{
    sarray[semid].count--;
    kprintf("DOWN");
  }
  return 0;
}

int syssem_delete(int semid){
  return 0;
}
