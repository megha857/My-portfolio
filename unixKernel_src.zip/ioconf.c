/*      file:           ioconf.c
*       author:         betty o'neil
*       edited by:      Megha Sharma
*       device independent I/O switch
*/

#include "ioconf.h"
#include "tty.h"

struct	device	devtab[] = {
/* TTY0 */
{0,ttyinit, ttyread, ttywrite, ttycontrol, 0x3f8,(int)&ttytab[0]},
 /* TTY1*/
{1,ttyinit, ttyread, ttywrite, ttycontrol, 0x2f8,(int)&ttytab[1]},
};
