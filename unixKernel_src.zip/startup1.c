/* Megha Sharma 
 C startup file, called from startup0.s-- */
void clr_bss(void);
void init_devio(void);
void k_init(void);
void startupc(void);

void startupc(void)
{
  /* clear BSS area (uninitialized data) */
  clr_bss();			
  /* latch onto Tutor-supplied info, code */
  init_devio();		
  /* start kernel */
  k_init();			
}
