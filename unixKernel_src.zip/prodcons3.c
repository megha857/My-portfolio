/*
*       edited by: Megha Sharma  
*       file:        prodcons3.c
*/
/* This uses semaphores in the normal way to share a buffer of
   As it runs, it records the sequence of producer "p" actions
   and consumer "c" actions in a global string "report".  When
   the consumer finishes, it writes out the string.  This way,
   the main run is not disturbed by i/o delays.
*/
#include <stdio.h>
#include <string.h>
#include "tunistd.h"
/* #include "semaphore.h" uncomment asap */
#include "intqueue/intqueue.h"
#include "prodcons.h"
static void printline(char *s);
static void consumer_delay(void);
int main3(void);

/* consumer */
int main3()
{
    int item = 0;
    char msg1[20];

    /* do some output to make sure main1 runs before consumer loop 
	 make sure main1 runs first */
    printline("consumer-start"); 
	/* consumer loop */
    while (item < NITEMS - 1) {
	/*	down(full); 
		down(mutex); */
	item = i_dequeue(&buffer);
	/* make mutex hold a while */
	sleep(CONSUMER_SLEEP);	
	if (item >= 0)
	    sprintf(msg1,"[c%d]", item);
	else 
		/* queue was empty */
	    sprintf(msg1,"[cXXX]");  
		/* under mutex */
	strcat(report, msg1); 
	/*	up(mutex); 
		up(empty); 
		consumer "consuming" */
	consumer_delay();  
    }
    /* output report of c's and p's */
    printline(report);
    return 0;
}

static void printline(char *s)
{
    write(TTY1, s, strlen(s)); 
    write(TTY1,"\r\n",2);
}

/* little delay to mimic work on item for consumer */
static void consumer_delay()
{
    int i;

    for (i=0;i<DELAYCOUNT_CONSUMER; i++)
	;
}



