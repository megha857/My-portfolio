/* Megha Sharma */
#include <stdio.h>
#include "tunistd.h"
#include "semaphore.h" /* uncomment this when you have this API file */
#include "testmutex.h"
static void printline(char *s);
int main3(void);

int main1()
{
    /* make sure main1 runs first and creates mutex */
    sleep(50);

    printline("C requests mutex...");
    down(mutex); 
    printline("...C has mutex");
	/* see if it holds */
    sleep(500);  
    printline("C is releasing mutex");
    up(mutex);
    return 0;
}

static void printline(char *s)
{
    write(TTY1, s, strlen(s)); 
    write(TTY1,"\r\n",2);
}
