/* Megha Sharma */

#include "intqueue/intqueue.h"
#define ARRAYSIZE 10

typedef struct semaphore {
	int count;
	int active;
  IntQueue processlist;
} semaphore;

semaphore sarray[ARRAYSIZE];

int syssem_create(int init_count);

int semsysup(int semid);

int semsysdown(int semid);

int syssem_delete(int semid);
