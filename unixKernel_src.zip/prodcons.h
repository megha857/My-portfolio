/*
*       edited by: Megha Sharma  
*       file:        prodcons.h
*/

/* number of spots in shared buffer */
#define N 5
/* number of fake items to process */
#define NITEMS 30
/* size of delay to mimic producer/consumer work */
#define PRODUCER_SLEEP 10
#define CONSUMER_SLEEP 30

/* these are small delays: under 2 minutes */
/* For a preemptive scheduler, trying 200,0000 or so here to see a tick during a delay loop */
#define DELAYCOUNT_PRODUCER 100000
#define DELAYCOUNT_CONSUMER 100000

/* globals set up by main1, used by main1 and main2 */
extern int mutex, empty, full; 
/* for in-memory buffer of record of consumer/producer actions */
/* max report string length: need one [pxx] and one [cxx] per item */
#define MAXREPORT (100 + NITEMS*8)
extern char report[MAXREPORT];
extern IntQueue buffer;

/* no strings.h header */ 
/*char *strcat(char *s1, const char *s2);*/  

