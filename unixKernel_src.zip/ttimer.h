/* Start ticking service that calls app_tick_callback every interval usecs */
void init_ticks(void);

/* Shut down ticking service */
void shutdown_ticks(void);
