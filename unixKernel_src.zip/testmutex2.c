/* Megha Sharma
 * file: testmutex2.c  First semaphore test, process 2:
 * uses one semaphore, used as mutex
 * NOTE: Uncomment the semaphore calls for the real test.
 */

#include <stdio.h>
#include "tunistd.h"
/* uncommented the next line after the API file was available */
#include "semaphore.h"  
/* for shared variable mutex */
#include "testmutex.h"
static void printline(char *s);
int main2(void);

int main2()
{
    /* main1 must run first and create mutex */
    sleep(50);

    printline("A requests mutex...");
    down(mutex);
    printline("...A has mutex");
	/* must be able to hold over time */
    sleep(500);  
    printline("After .5 sec sleep, A is releasing mutex");
    up(mutex); 
    return 0;
}


static void printline(char *s)
{
    write(TTY1, s, strlen(s)); 
    write(TTY1,"\r\n",2);
}
