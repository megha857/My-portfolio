/* Megha Sharma
 * file: testmutex3.c  First semaphore test, process 3:
 * uses one semaphore, used as mutex
 * NOTE: Uncomment the semaphore calls for the real test.
 */

#include <stdio.h>
#include "tunistd.h"
/* uncommented the next line after the API file was available */
#include "semaphore.h" 
#include "testmutex.h"
static void printline(char *s);
int main3(void);

int main3()
{
    /* main1 must run first and create mutex */
    sleep(50);

    printline("B requests mutex...");
    down(mutex); 
    printline("...B has mutex");
	/* see if it holds */
    sleep(500);  
    printline("B is releasing mutex");
    up(mutex);
    return 0;
}

static void printline(char *s)
{
    write(TTY1, s, strlen(s)); 
    write(TTY1,"\r\n",2);
}
