/*      file:           conf.h
*       author:         betty o'neil
*       edited by:      Megha Sharma
*       Device table declarations
*/

#ifndef IOCONF_H
#define IOCONF_H

	/* device table entry */
struct  device  {     
	/* dev no. */         
    int	dvnum;			
	/* init routine for dev */
    void (*dvinit)(int dev);	 
	/* read function for device */
    int	(*dvread)(int dev, char *buf, int n);  
	/* write function for device */
    int	(*dvwrite)(int dev, char *buf, int n);  
	/* control function for device */
    int (*dvcontrol)(int dev, int code, int x); 
	/* base port for hardware registers */
    int	dvbaseport;		
	/* address of software data */
    int dvdata;			
};
/* one struct per device */
extern	struct	device devtab[]; 

/* Note this needs to agree with # devices in ioconf.c */
#define NDEVS 2
#endif
