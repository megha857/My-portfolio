
Unix kernel - source code (C and assembly)
by Megha Sharma

This is a small unix kernel.

It is designed to be compiled and run on an i386 computer.
