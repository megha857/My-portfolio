/*
*       file:           io.c
*       author:         betty o'neil
*       edited by:      Megha Sharma
*       device-independent i/o package for SAPC
*/

#include "ioconf.h"
#include "tsystm.h"

/* i/o initialization loop for SAPC devices */

void ioinit()
{
  int i;

  for (i = 0; i < NDEVS; i++)
  /* call device-specific init routine */
    devtab[i].dvinit(i);	
}

/* read function calling routine for SAPC devices */

int sysread(int dev, char *buf, int nchar)
{
   /* fail */
  if (dev < 0 || dev >= NDEVS) return -1;   
  /* call device-specific routine */
  return devtab[dev].dvread(dev, buf, nchar); 
}

/* write function calling routine for SAPC devices */
int syswrite(int dev, char *buf, int nchar)
{ 
  /* fail */
  if (dev < 0 || dev >= NDEVS) return -1;  
  /* call device-specific routine */   
  return devtab[dev].dvwrite(dev, buf, nchar); 
}

/* control function calling routine for SAPC devices */
 
 /* note: val could be pointer */
int syscontrol(int dev, int fncode, int val) 
{ 
  /* fail */
  if (dev < 0 || dev >= NDEVS) return -1;  
  /* call device-specific routine */  
  return devtab[dev].dvcontrol(dev, fncode, val);
}
