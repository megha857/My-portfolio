
Space simulation - binary executable QT requirements
by Megha Sharma

This is a 3d space simulation.  My contribution to this project was the user interface.

This contains QT dlls that are required to run the space simulation application.  If QT is installed then these DLLs will already exist.

