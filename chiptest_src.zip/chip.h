/*
*   file:   chip.h
*   author: Betty O'Neil
    co-author: Megha Sharma
* Header file for chip tester program--data structure for interface
*   between chip-specific code and mainline code 
*/

/* type for pointer to function that returns int, takes int and int pointer */

typedef int (*PFI_I_IPTR)(int, int *);

typedef struct {
	
	/* "LS00" or whatever */
  char *chipname;		
  /* description string */
  char *chipdesc;		
  /* no. of logic-1 pins */
  int n_highpins;	
  /* array of logic-1 pin nos. */	
  int *highpins;
  /* no. of logic-0 pins */		
  int n_lowpins;	
  /* array of logic-0 pin nos. */	
  int *lowpins;	
  /* no. of input pins */		
  int n_inpins;	
  /* array of input pin nos. */		
  int *inpins;	
  /* no. of output pins */		
  int n_outpins;	
  /* array of output pin nos. */	
  int *outpins;	
  /* does chip logic in software */	
  PFI_I_IPTR softchip;		
} Chip;
