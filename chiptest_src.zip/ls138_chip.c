/*
	Megha Sharma
	CS341
	MP4

*/


#include "chip.h"

/* chip pin configuration via arrays of pin numbers where arrays are only 
   accessed via chip i.e., they are the building-blocks of the bigger data
   structure for the chip */
   
  /* VCC and any active high enable inputs */  
static int high_pindata[] = { 16 }; 
/* GND and any active low enable inputs */
static int low_pindata[] = { 8 };   
static int input_pindata[] = { 1, 2, 3, 4, 5, 6};
static int output_pindata[] = { 15, 14, 13, 12, 11 };

/* softchip is called via Chip's softchip member */
static int ls138_softchip(int inpins,int *outpins);

/* The master data structure for an LS138 chip: everything the
 main program needs to know about this chip */

Chip ls138 = {"LS138","3-to-8 decoder",
	    sizeof(high_pindata)/sizeof(high_pindata[0]),high_pindata,
	    sizeof(low_pindata)/sizeof(low_pindata[0]),low_pindata,
	    sizeof(input_pindata)/sizeof(input_pindata[0]),input_pindata,
	    sizeof(output_pindata)/sizeof(output_pindata[0]),output_pindata,
	    ls138_softchip};

/* compute outputs for given inputs in bits of int input-- */

static int ls138_softchip( int input, int *output ) {

	int bit_sequence, output_sequence;

	if((input >> 3) != 0x04)
		*output = 0x1f;
	else {
		bit_sequence = input & 0x07;
		output_sequence = (0x01 << (bit_sequence));
		*output = ~output_sequence & 0x1f;
	} 
    return 1;
}





