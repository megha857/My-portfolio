
Parallel port driver and chiptest - source code (C and assembly)
by Megha Sharma

This is the parallel port driver and chip testing program that I wrote for a unix kernel.

It is designed to be compiled and run on an i386 computer running the "tutor" operating system.
