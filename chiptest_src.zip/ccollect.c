/* Megha Sharma */

#include <stdio.h>     
#ifdef SAPC
/* serial communications header */
#include <serial.h>	
/* LPT header */	
#include <lp.h>			
/* for inpt/outpt prototypes */
#include <cpu.h>		
#endif


void collect(char * data, int maxdata);

void collect(char * data, int maxdata) {
	int i;
  
 	for(i = 0; i < maxdata; i++) {
		#ifdef SAPC
		data[i] = (inpt(LPT1_BASE + LP_STATUS) & LP_PBUSY) >> 7;
		#endif
	}
}
