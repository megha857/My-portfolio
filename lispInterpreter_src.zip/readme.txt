
Lisp interpreter - source code (scheme)
by Megha Sharma

This is a Lisp interpreter, written to be run from within scheme (R5RS).

It is compliant with the full Scheme specs.

