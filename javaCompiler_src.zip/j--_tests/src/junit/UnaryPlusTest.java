
package junit;

import junit.framework.TestCase;
import pass.UnaryPlus;

public class UnaryPlusTest extends TestCase
{
	private UnaryPlus unaryPlus;

	@Override
	protected void setUp() throws Exception
	{
		super.setUp();
		unaryPlus = new UnaryPlus();
	}
	
	@Override
	protected void tearDown() throws Exception
	{
		super.tearDown();
	}
	
	public void testPlus()
	{
		this.assertEquals(0, unaryPlus.unaryPlus(0));
		this.assertEquals(1, unaryPlus.unaryPlus(1));
		this.assertEquals(127, unaryPlus.unaryPlus(127));
		this.assertEquals(127, unaryPlus.unaryPlus(unaryPlus.unaryPlus(unaryPlus.unaryPlus(127))));
	}
}
