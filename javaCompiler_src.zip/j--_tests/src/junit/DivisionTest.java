
package junit;

import junit.framework.TestCase;
import pass.Division;

public class DivisionTest extends TestCase
{
	private Division division;

	@Override
	protected void setUp() throws Exception
	{
		super.setUp();
		division = new Division();
	}
	
	@Override
	protected void tearDown() throws Exception
	{
		super.tearDown();
	}
	
	public void testDivide()
	{
		this.assertEquals(0, division.divide(0, 42));
		this.assertEquals(42, division.divide(42, 1));
		this.assertEquals(42, division.divide(127, 3));
	}
}
