
package junit;

import junit.framework.TestCase;
import pass.ScannerAdditions;
import jminusminus.Scanner;
import jminusminus.TokenInfo;
import jminusminus.TokenKind;

public class ScannerAdditionsTest extends TestCase
{
	TokenInfo[] sampleTokens, operatorTokens, keywordTokens, doubleTokens;
	Scanner baseScanner, badBaseScanner;
	Scanner commentScanner1, commentScanner2, commentScanner3, commentScanner4, commentScanner5, commentScanner6;
	Scanner operatorScanner, keywordScanner, doubleScanner;
	
	@Override
	protected void setUp() throws Exception
	{
		super.setUp();
		
		// Token checks
		sampleTokens = new TokenInfo[] {
			new TokenInfo(TokenKind.IMPORT, "import", 0),
			new TokenInfo(TokenKind.IDENTIFIER, "java", 0),
			new TokenInfo(TokenKind.DOT, ".", 0),
			new TokenInfo(TokenKind.IDENTIFIER, "io", 0),
			new TokenInfo(TokenKind.DOT, ".", 0),
			new TokenInfo(TokenKind.IDENTIFIER, "File", 0),
			new TokenInfo(TokenKind.SEMI, ";", 0),
		};
		
		operatorTokens = new TokenInfo[] {
			new TokenInfo(TokenKind.ASSIGN, "=", 0),
			new TokenInfo(TokenKind.PLUS, "+", 0),
			new TokenInfo(TokenKind.MINUS, "-", 0),
			new TokenInfo(TokenKind.STAR, "*", 0),
			new TokenInfo(TokenKind.DIV, "/", 0),
			new TokenInfo(TokenKind.MOD, "%", 0),
			new TokenInfo(TokenKind.PLUS_ASSIGN, "+=", 0),
			new TokenInfo(TokenKind.MINUS_ASSIGN, "-=", 0),
			new TokenInfo(TokenKind.LNOT, "!", 0),
			new TokenInfo(TokenKind.EQUAL, "==", 0),
			new TokenInfo(TokenKind.NOT_EQUAL, "!=", 0),
			new TokenInfo(TokenKind.GT, ">", 0),
			new TokenInfo(TokenKind.GE, ">=", 0),
			new TokenInfo(TokenKind.LT, "<", 0),
			new TokenInfo(TokenKind.LE, "<=", 0),
			new TokenInfo(TokenKind.LAND, "&&", 0),
			new TokenInfo(TokenKind.LOR, "||", 0),
			//new TokenInfo(TokenKind.TERNARY, "?:", 0),
			new TokenInfo(TokenKind.BIT_COMPLEMENT, "~", 0),
			new TokenInfo(TokenKind.BIT_LSHIFT, "<<", 0),
			new TokenInfo(TokenKind.BIT_RSHIFT, ">>", 0),
			new TokenInfo(TokenKind.BIT_UNSIGNED_RSHIFT, ">>>", 0),
			new TokenInfo(TokenKind.BIT_AND, "&", 0),
			new TokenInfo(TokenKind.BIT_OR, "|", 0),
			new TokenInfo(TokenKind.BIT_XOR, "^", 0),
			new TokenInfo(TokenKind.TERNARY1, "?", 0),
			new TokenInfo(TokenKind.TERNARY2, ":", 0),
		};
		keywordTokens = new TokenInfo[] {
				new TokenInfo(TokenKind.ABSTRACT, "abstract", 0),
				new TokenInfo(TokenKind.ASSERT, "assert", 0),
				new TokenInfo(TokenKind.BOOLEAN, "boolean", 0),
				new TokenInfo(TokenKind.BREAK, "break", 0),
				new TokenInfo(TokenKind.BYTE, "byte", 0),
				new TokenInfo(TokenKind.CASE, "case", 0),
				new TokenInfo(TokenKind.CATCH, "catch", 0),
				new TokenInfo(TokenKind.CHAR, "char", 0),
				new TokenInfo(TokenKind.CLASS, "class", 0),
				new TokenInfo(TokenKind.CONST, "const", 0),
				new TokenInfo(TokenKind.CONTINUE, "continue", 0),
				new TokenInfo(TokenKind.DEFAULT, "default", 0),
				new TokenInfo(TokenKind.DO, "do", 0),
				new TokenInfo(TokenKind.DOUBLE, "double", 0),
				new TokenInfo(TokenKind.ELSE, "else", 0),
				new TokenInfo(TokenKind.ENUM, "enum", 0),
				new TokenInfo(TokenKind.EXTENDS, "extends", 0),
				new TokenInfo(TokenKind.FINAL, "final", 0),
				new TokenInfo(TokenKind.FINALLY, "finally", 0),
				new TokenInfo(TokenKind.FLOAT, "float", 0),
				new TokenInfo(TokenKind.FOR, "for", 0),
				new TokenInfo(TokenKind.GOTO, "goto", 0),
				new TokenInfo(TokenKind.IF, "if", 0),
				new TokenInfo(TokenKind.IMPLEMENTS, "implements", 0),
				new TokenInfo(TokenKind.IMPORT, "import", 0),
				new TokenInfo(TokenKind.INSTANCEOF, "instanceof", 0),
				new TokenInfo(TokenKind.INT, "int", 0),
				new TokenInfo(TokenKind.INTERFACE, "interface", 0),
				new TokenInfo(TokenKind.LONG, "long", 0),
				new TokenInfo(TokenKind.NATIVE, "native", 0),
				new TokenInfo(TokenKind.NEW, "new", 0),
				new TokenInfo(TokenKind.PACKAGE, "package", 0),
				new TokenInfo(TokenKind.PRIVATE, "private", 0),
				new TokenInfo(TokenKind.PROTECTED, "protected", 0),
				new TokenInfo(TokenKind.PUBLIC, "public", 0),
				new TokenInfo(TokenKind.RETURN, "return", 0),
				new TokenInfo(TokenKind.SHORT, "short", 0),
				new TokenInfo(TokenKind.STATIC, "static", 0),
				new TokenInfo(TokenKind.STRICTFP, "strictfp", 0),
				new TokenInfo(TokenKind.SUPER, "super", 0),
				new TokenInfo(TokenKind.SWITCH, "switch", 0),
				new TokenInfo(TokenKind.SYNCHRONIZED, "synchronized", 0),
				new TokenInfo(TokenKind.THIS, "this", 0),
				new TokenInfo(TokenKind.THROW, "throw", 0),
				new TokenInfo(TokenKind.THROWS, "throws", 0),
				new TokenInfo(TokenKind.TRANSIENT, "transient", 0),
				new TokenInfo(TokenKind.TRY, "try", 0),
				new TokenInfo(TokenKind.VOID, "void", 0),
				new TokenInfo(TokenKind.VOLATILE, "volatile", 0),
				new TokenInfo(TokenKind.WHILE, "while", 0)
			};
			doubleTokens = new TokenInfo[] {
				new TokenInfo(TokenKind.DOUBLE_LITERAL, "0.0", 0),
				new TokenInfo(TokenKind.DOUBLE_LITERAL, "3.14", 0),
				new TokenInfo(TokenKind.DOUBLE_LITERAL, "3.14d", 0),
				new TokenInfo(TokenKind.DOUBLE_LITERAL, "3.14e52", 0),
				new TokenInfo(TokenKind.DOUBLE_LITERAL, "3.14e+52", 0),
				new TokenInfo(TokenKind.DOUBLE_LITERAL, "3.14e-52", 0),
				new TokenInfo(TokenKind.DOUBLE_LITERAL, "3.1_4", 0),
				new TokenInfo(TokenKind.DOUBLE_LITERAL, "3.1_4d", 0),
				new TokenInfo(TokenKind.DOUBLE_LITERAL, "3.1_4e5_2", 0),
			};
		// scanners
		try
		{
			baseScanner = new Scanner("import java.io.File;", false);
			badBaseScanner = new Scanner("package 123 + 456 + if void", false);
			commentScanner1 = new Scanner("import java./* this shouldn't impact stuff */io.File;", false);
			commentScanner2 = new Scanner("import java. /* multiline added here\n but shouldn't impact stuff*/ io.File;", false);
			commentScanner3 = new Scanner("import java./* this shouldn't // impact stuff */io.File;", false);
			commentScanner4 = new Scanner("import java.io.File; // /* this shouldn't impact stuff */", false);
			commentScanner5 = new Scanner("import /* this should create an error", false);
			commentScanner6 = new Scanner("import java.io.File; //*skip1*/\n    /** skip2 *****/\n    /*\n     *\n     *skip3\n     skip4\n*/\n    /*\n      skip5\n    */\n    /***//**/\n", false);
			operatorScanner = new Scanner("= + - * / % += -= ! == != > >= < <= && || ~ << >> >>> & | ^ ? : ", false);
			keywordScanner = new Scanner("abstract assert boolean break byte case catch char class const continue default do double else enum extends final finally float for goto if implements import instanceof int interface long native new package private protected public return short static strictfp super switch synchronized this throw throws transient try void volatile while", false);
			doubleScanner = new Scanner("0.0 3.14 3.14d 3.14e52 3.14e+52 3.14e-52 3.1_4 3.1_4d 3.1_4e5_2", false);
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}
	
	@Override
	protected void tearDown() throws Exception
	{
		super.tearDown();
	}
	
	public void testScanner_base()
	{
		checkTokenEquality(sampleTokens, baseScanner, true);
	}
	public void testScanner_badBase()
	{
		checkTokenEquality(sampleTokens, badBaseScanner, false);
	}
	public void testScanner_comment()
	{
		checkTokenEquality(sampleTokens, commentScanner1, true);
		checkTokenEquality(sampleTokens, commentScanner2, true);
		checkTokenEquality(sampleTokens, commentScanner3, true);
		checkTokenEquality(sampleTokens, commentScanner4, true);
		checkTokenEquality(sampleTokens, commentScanner6, true);
		commentScanner5.getNextToken();
		commentScanner5.getNextToken();
		if(!commentScanner5.errorHasOccurred())
		{
			this.fail("Didn't receive error on EOF before end of multiline comment");
		}
	}
	public void testScanner_operator()
	{
		checkTokenEquality(operatorTokens, operatorScanner, true);
	}
	public void testScanner_keyword()
	{
		checkTokenEquality(keywordTokens, keywordScanner, true);
	}
	public void testScanner_double()
	{
		checkTokenEquality(doubleTokens, doubleScanner, true);
	}
	
	public void checkTokenEquality(TokenInfo[] tokens, Scanner scanner, boolean wantEqual)
	{
		int i = 0;
		for(TokenInfo expected : tokens)
		{
			TokenInfo token = scanner.getNextToken();
			if(token.kind() == TokenKind.EOF)
			{
				this.fail("Incorrect token count.  Expected:" + tokens.length + " found: " + i);
			}
			if(wantEqual)
			{
				this.assertEquals("Token type inequality.  Expected: " + expected.kind() + ".  Scanned: " + token.kind() + ".\n", token.kind(), expected.kind());
				this.assertEquals("Token image inequality.  Expected: '" + expected.image() + "'.  Scanned: '" + token.image() + "'.\n", token.image(), expected.image());
			}
			else
			{
				this.assertNotSame("Unwanted token type equality: " + expected.kind() + ".\n", token.kind(), expected.kind());
				this.assertNotSame("Unwanted token image equality: '" + expected.image() + "'.\n", token.image(), expected.image());
			}
			i++;
		}
		TokenInfo token = scanner.getNextToken();
		if(token.kind() != TokenKind.EOF)
		{
			while(token.kind() != TokenKind.EOF)
			{
				token = scanner.getNextToken();
				i++;
			}
			this.fail("Incorrect token count.  Expected:" + tokens.length + " found: " + i);
		}
	}
}
