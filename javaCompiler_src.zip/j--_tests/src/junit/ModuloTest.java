
package junit;

import junit.framework.TestCase;
import pass.Modulo;

public class ModuloTest extends TestCase
{
	private Modulo modulo;

	@Override
	protected void setUp() throws Exception
	{
		super.setUp();
		modulo = new Modulo();
	}
	
	@Override
	protected void tearDown() throws Exception
	{
		super.tearDown();
	}
	
	public void testModulo()
	{
		this.assertEquals(0, modulo.modulo(12, 12));
		this.assertEquals(1, modulo.modulo(13, 12));
		this.assertEquals(1, modulo.modulo(127, 3));
	}
}
