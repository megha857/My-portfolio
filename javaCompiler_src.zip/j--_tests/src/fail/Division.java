
package fail;

public class Division
{
	public static void main(String[] args)
	{
		System.out.println('a' / 3 );
	}
}
