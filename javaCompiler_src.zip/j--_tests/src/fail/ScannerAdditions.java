
package fail;

import jminusminus.Scanner;

public class ScannerAdditions
{
	public void tryScanner(String src)
	{
		Scanner s = new Scanner(src, false, "make sure you fail here!");
		s.getNextToken();
	}
}
