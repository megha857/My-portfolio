
package fail;

public class Modulo
{
	public static void main(String[] args)
	{
		System.out.println('a' % 3 );
	}
}
