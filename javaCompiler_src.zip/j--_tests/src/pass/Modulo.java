
package pass;

public class Modulo
{
	public int modulo(int a, int b)
	{
		return a % b;
	}
}
