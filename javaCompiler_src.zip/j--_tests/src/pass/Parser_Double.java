
package pass;

import java.lang.System;

public class Parser_Double
{
//	public static int main(String[] args)
//	{
//		System.out.println("hi");
//	}
	
	public void method()
	{
		double var = 1.0;
	}
}