
package pass;

public class Parser_Blocks {
	static
	{
		String i = "heyooo!";
	}
	
	{
		String j = "ow!";
	}
	
	static
	{
		int i = 35;
	}
	
	{
		int j = 0;
	}
	
	public void func()
	{
	}
}
