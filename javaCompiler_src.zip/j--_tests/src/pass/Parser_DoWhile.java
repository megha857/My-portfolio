
package pass;

import java.lang.System;

public class Parser_DoWhile
{
//	public static int main(String[] args)
//	{
//		System.out.println("hi");
//	}
	
	int i = 1;
	
	public void method()
	{
		do
		{
			i=1;
		}
		while(i == 1);
		
		if(i == 1)
		{
			i=1;
		}
	}
}