
package pass;

public class Division
{
	public int divide(int a, int b)
	{
		return a / b;
	}
}
