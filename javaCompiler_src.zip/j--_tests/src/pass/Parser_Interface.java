
package pass;

public interface Parser_Interface
{
	public int i = 0;
	public int method(int j);
}
