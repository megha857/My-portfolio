
package pass;

import java.lang.System;

public class Parser_Operators
{
//	public static int main(String[] args)
//	{
//		System.out.println("hi");
//	}
	
	public void method()
	{
		int i = 0;
		i += 2;
		i -= 2;
		i *= 2;
		i /= 2;
		i %= 2;
		i++;
		i--;
		++i;
		--i;
		double j = 5;
		j += 2;
		j -= 2;
		j *= 2;
		j /= 2;
		j %= 2;
		j++;
		j--;
		++j;
		--j;
		String k = "hi";
		k += 5;
//		k -= "dude";
//		k *= "shutup!";
//		k /= "dude";
//		k %= "shutup!";
		if(true || false)
		{
			i = 1;
		}
		
		i = true ? i+3 : (int)j;
	}
}
