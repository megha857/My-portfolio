
package pass;

import java.io.FileNotFoundException;

import jminusminus.Scanner;

public class ScannerAdditions
{
	public void tryScanner(String src)
	{
		Scanner s;
		try {
			s = new Scanner(src, false);
			s.getNextToken();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
