
package pass;

public class UnaryPlus
{
	public int unaryPlus(int a)
	{
		return +a;
	}
}
