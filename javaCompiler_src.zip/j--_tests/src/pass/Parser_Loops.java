
package pass;

public class Parser_Loops
{
	public void method()
	{
		int f = 0;
		for(int i = 0; i < 10; i++)
		{
			f++;
		}
		
		switch(f)
		{
		case 1:
			f = 2;
			f = 5;
			break;// smartee;
		case 2:
			f = 3;
		default:
			f=-1;
		}
	}

}
