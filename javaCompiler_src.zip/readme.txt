
Java Compiler - java source
by Megha Sharma

Java compiler serves the purpose of "javac" in the java JDK.

This is the source code for my Java compiler.

It is setup to be compiled with "ant".  The build.xml file is located in the "src" directory.
