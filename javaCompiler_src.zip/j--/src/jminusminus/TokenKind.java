
package jminusminus;

/**
 * An enum of token kinds. Each entry in this enum represents the kind of a
 * token along with its image (string representation).
 * 
 * When you add a new token to the scanner, you must also add an entry to this
 * enum specifying the kind and image of the new token.
 */

public enum TokenKind {
    EOF("<EOF>"), ABSTRACT("abstract"), BOOLEAN("boolean"), CHAR("char"), CLASS(
            "class"), ELSE("else"), EXTENDS("extends"), FALSE("false"), IF("if"), IMPORT(
            "import"), INSTANCEOF("instanceof"), INT("int"), NEW("new"), NULL(
            "null"), PACKAGE("package"), PRIVATE("private"), PROTECTED(
            "protected"), PUBLIC("public"), RETURN("return"), STATIC("static"), SUPER(
            "super"), THIS("this"), TRUE("true"), VOID("void"), WHILE("while"), PLUS(
            "+"), ASSIGN("="), DEC("--"), EQUAL("=="), GT(">"), INC("++"), LAND(
            "&&"), LE("<="), LNOT("!"), MINUS("-"), PLUS_ASSIGN("+="), STAR("*"), LPAREN(
            "("), RPAREN(")"), LCURLY("{"), RCURLY("}"), LBRACK("["), RBRACK(
            "]"), SEMI(";"), COMMA(","), DOT("."), IDENTIFIER("<IDENTIFIER>"), INT_LITERAL(
            "<INT_LITERAL>"), CHAR_LITERAL("<CHAR_LITERAL>"), STRING_LITERAL(
            "<STRING_LITERAL>"), DIV("/"), MOD("%"),
            // Addition 1 - keywords
            ASSERT("assert"),
            BREAK("break"),
            BYTE("byte"),
            CASE("case"),
            CATCH("catch"),
            CONST("const"),
            CONTINUE("continue"),
            DEFAULT("default"),
            DO("do"),
            DOUBLE("double"),
            ENUM("enum"),
            FINAL("final"),
            FINALLY("finally"),
            FLOAT("float"),
            FOR("for"),
            GOTO("goto"),
            IMPLEMENTS("implements"),
            INTERFACE("interface"),
            LONG("long"),
            NATIVE("native"),
            SHORT("short"),
            STRICTFP("strictfp"),
            SWITCH("switch"),
            SYNCHRONIZED("synchronized"),
            THROW("throw"),
            THROWS("throws"),
            TRANSIENT("transient"),
            TRY("try"),
            VOLATILE("volatile"),
            // Addition 1 - operators
            MINUS_ASSIGN("-="),
            STAR_ASSIGN("*="),
            DIV_ASSIGN("/="),
            MOD_ASSIGN("%="),
            NOT_EQUAL("!="),
            GE(">="),
            LT("<"),
            LOR("||"),
            BIT_COMPLEMENT("~"),
            BIT_LSHIFT("<<"),
            BIT_RSHIFT(">>"),
            BIT_UNSIGNED_RSHIFT(">>>"),
            BIT_AND("&"),
            BIT_OR("|"),
            BIT_XOR("^"),
            TERNARY1("?"),
            TERNARY2(":"),
            // Addition 1 - double
            DOUBLE_LITERAL("<DOUBLE_LITERAL>"),
            ;

    /** The token's string representation. */
    private String image;

    /**
     * Construct an instance TokenKind given its string representation.
     * 
     * @param image
     *            string representation of the token.
     */

    private TokenKind(String image) {
        this.image = image;
    }

    /**
     * Return the image of the token.
     * 
     * @return the token's image.
     */

    public String image() {
        return image;
    }

    /**
     * Return the string representation of the token.
     * 
     * @return the token's string representation.
     */

    public String toString() {
        return image;
    }

}
