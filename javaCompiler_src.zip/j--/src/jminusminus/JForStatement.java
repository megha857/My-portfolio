// Copyright 2013 Bill Campbell, Swami Iyer and Bahar Akbal-Delibas

package jminusminus;

import static jminusminus.CLConstants.*;

import java.util.ArrayList;

/**
 * The AST node for a while-statement.
 */

class JForStatement extends JStatement {

    /** Initializer */
    private ArrayList<JStatement> init;
    private JVariableDeclaration init2;

    /** Test expression. */
    private JExpression condition;

    /** Initializer */
    private ArrayList<JStatement> update;

    /** The body. */
    private JStatement body;

    /**
     * Construct an AST node for a while-statement given its line number, the
     * test expression, and the body.
     * 
     * @param line
     *            line in which the while-statement occurs in the source file.
     * @param condition
     *            test expression.
     * @param body
     *            the body.
     */

    public JForStatement(int line, ArrayList<JStatement> init, JExpression condition,
    		ArrayList<JStatement> update, JStatement body) {
        super(line);
        this.init = init;
        this.init2 = null;
        this.condition = condition;
        this.update = update;
        this.body = body;
    }

    public JForStatement(int line, JVariableDeclaration init, JExpression condition,
    		ArrayList<JStatement> update, JStatement body) {
        super(line);
        this.init = null;
        this.init2 = init;
        this.condition = condition;
        this.update = update;
        this.body = body;
    }

    /**
     * Analysis involves analyzing the test, checking its type and analyzing the
     * body statement.
     * 
     * @param context
     *            context in which names are resolved.
     * @return the analyzed (and possibly rewritten) AST subtree.
     */

    public JForStatement analyze(Context context) {
    	if(init == null) {
    		init2.analyze(context);
    	}
    	else {
	        for(JStatement statement : init) {
	        	statement.analyze(context);
	        }
    	}
        condition.analyze(context);
        condition.type().mustMatchExpected(line(), Type.BOOLEAN);
        for(JStatement statement : update) {
        	statement.analyze(context);
        }
        body.analyze(context);
        return this;
    }

    /**
     * Generate code for the while loop.
     * 
     * @param output
     *            the code emitter (basically an abstraction for producing the
     *            .class file).
     */

    public void codegen(CLEmitter output) {
        // Need two labels
        String test = output.createLabel();
        String out = output.createLabel();

        // Init
        if(init == null) {
        	init2.codegen(output);
        }
        else {
	        for(JStatement statement : init) {
	        	statement.codegen(output);
	        }        	
        }
        
        // Branch out of the loop on the test condition
        // being false
        output.addLabel(test);
        condition.codegen(output, out, false);

        // Codegen body
        body.codegen(output);

        // Update
        for(JStatement statement : update) {
        	statement.codegen(output);
        }

        // Unconditional jump back up to test
        output.addBranchInstruction(GOTO, test);

        // The label below and outside the loop
        output.addLabel(out);
    }

    /**
     * @inheritDoc
     */

    public void writeToStdOut(PrettyPrinter p) {
        p.printf("<JForStatement line=\"%d\">\n", line());
        p.indentRight();
        p.printf("<InitExpressions>\n");
        p.indentRight();
        if(init == null) {
        	init2.writeToStdOut(p);
        }
        else {
	        for(JStatement i : init)
	        {
	        	i.writeToStdOut(p);
	        }
        }
        p.indentLeft();
        p.printf("</InitExpressions>\n");
        p.printf("<TestExpression>\n");
        p.indentRight();
        condition.writeToStdOut(p);
        p.indentLeft();
        p.printf("</TestExpression>\n");
        p.printf("<UpdateExpressions>\n");
        p.indentRight();
        for(JStatement i : update)
        {
        	i.writeToStdOut(p);
        }
        p.indentLeft();
        p.printf("</UpdateExpressions>\n");
        p.printf("<Body>\n");
        p.indentRight();
        body.writeToStdOut(p);
        p.indentLeft();
        p.printf("</Body>\n");
        p.indentLeft();
        p.printf("</JForStatement>\n");
    }

}
