// Copyright 2013 Bill Campbell, Swami Iyer and Bahar Akbal-Delibas

package jminusminus;

import java.util.ArrayList;

/**
 * The AST node for a block, which delimits a nested level of scope.
 */

class JSwitchBlockStatementGroup extends JStatement {

	ArrayList<JExpression> switchLabels;
	boolean hasDefaultSwitchLabels = false;
	ArrayList<JStatement> statements;

    public JSwitchBlockStatementGroup(int line, ArrayList<JExpression> switchLabels,
    		boolean hasDefaultSwitchLabels, ArrayList<JStatement> statements) {
        super(line);
        this.switchLabels = switchLabels;
        this.hasDefaultSwitchLabels = hasDefaultSwitchLabels;
        this.statements = statements;
    }

    public ArrayList<JExpression> switchLabels() {
        return switchLabels;
    }
    
    public ArrayList<JStatement> statements()
    {
    	return statements;
    }

    public JSwitchBlockStatementGroup analyze(Context context) {
//        // { ... } defines a new level of scope.
//        this.context = new LocalContext(context);
//
//        for (int i = 0; i < statements.size(); i++) {
//            statements.set(i, (JStatement) statements.get(i).analyze(
//                    this.context));
//        }
        return this;
    }

    /**
     * Generating code for a block consists of generating code for each of its
     * statements.
     * 
     * @param output
     *            the code emitter (basically an abstraction for producing the
     *            .class file).
     */

    public void codegen(CLEmitter output) {
//        for (JStatement statement : statements) {
//            statement.codegen(output);
//        }
    }

    /**
     * @inheritDoc
     */

    public void writeToStdOut(PrettyPrinter p) {
        p.printf("<JSwitchBlockStatementGroup line=\"%d\">\n", line());
        if (hasDefaultSwitchLabels) {
            p.indentRight();
        	p.printf("<switchLabel type='default'/>\n");
            p.indentLeft();
        }
        for(JExpression i : switchLabels)
        {
            p.indentRight();
            p.printf("<switchLabel type='case'>\n");
            p.indentRight();
            i.writeToStdOut(p);
            p.indentLeft();
            p.printf("</switchLabel>\n");
            p.indentLeft();
        }
        for(JStatement i : statements)
        {
	        p.indentRight();
	        p.printf("<block>\n");
	        p.indentRight();
	        i.writeToStdOut(p);
	        p.indentLeft();
	        p.printf("</block>\n");
	        p.indentLeft();
        }
        p.printf("</JSwitchBlockStatementGroup>\n");
    }

}
