// Copyright 2013 Bill Campbell, Swami Iyer and Bahar Akbal-Delibas

package jminusminus;

import static jminusminus.CLConstants.*;


class JBreak extends JStatement {

	private String label;

    public JBreak(int line, String label) {
        super(line);
        this.label = label;
    }

    public JBreak analyze(Context context) {
        return this;
    }

    public void codegen(CLEmitter output) {
    }

    /**
     * @inheritDoc
     */

    public void writeToStdOut(PrettyPrinter p) {
        p.printf("<JBreak line=\"%d\" label=\"%s\"/>\n",
                line(), label);
    }

}
