// Copyright 2013 Bill Campbell, Swami Iyer and Bahar Akbal-Delibas

package jminusminus;

import static jminusminus.CLConstants.*;
import jminusminus.CLEmitter;

/**
 * The AST node for a binary expression. A binary expression has an operator and
 * two operands: a lhs and a rhs.
 */

public abstract class JTernaryExpression extends JExpression {

    /** The first ternary operator. */
    protected String operator1;

    /** The second ternary operator. */
    protected String operator2;

    /** The lhs operand. */
    protected JExpression lhs;

    /** The first rhs operand. */
    protected JExpression rhs1;

    /** The second rhs operand. */
    protected JExpression rhs2;

    /**
     * Construct an AST node for a ternary expression given its line number, the
     * two operators, and lhs, rhs1 and rhs2 operands.
     * 
     * @param line
     *            line in which the ternary expression occurs in the source file.
     * @param operator1
     *            the first operator.
     * @param operator2
     *            the second operator.
     * @param lhs
     *            the lhs operand.
     * @param rhs1
     *            the rhs1 operand.
     * @param rhs2
     *            the rhs2 operand.
     */

    protected JTernaryExpression(int line, String operator1, String operator2,
    		JExpression lhs, JExpression rhs1, JExpression rhs2) {
        super(line);
        this.operator1 = operator1;
        this.operator2 = operator2;
        this.lhs = lhs;
        this.rhs1 = rhs1;
        this.rhs2 = rhs2;
    }

    /**
     * @inheritDoc
     */

    public void writeToStdOut(PrettyPrinter p) {
        p.printf("<JTernaryExpression line=\"%d\" type=\"%s\" "
                + "operator1=\"%s\" operator2=\"%s\">\n",
                line(), ((type == null) ? "" : type.toString()),
                Util.escapeSpecialXMLChars(operator1),
                Util.escapeSpecialXMLChars(operator2));
        p.indentRight();
        p.printf("<Lhs>\n");
        p.indentRight();
        lhs.writeToStdOut(p);
        p.indentLeft();
        p.printf("</Lhs>\n");
        p.printf("<Rhs1>\n");
        p.indentRight();
        rhs1.writeToStdOut(p);
        p.indentLeft();
        p.printf("</Rhs1>\n");
        p.printf("<Rhs2>\n");
        p.indentRight();
        rhs2.writeToStdOut(p);
        p.indentLeft();
        p.printf("</Rhs2>\n");
        p.indentLeft();
        p.printf("</JTernaryExpression>\n");
    }

}

/**
 * The AST node for a conditional (?:) expression. In j--, as in Java, ?: is overloaded
 * to denote addition for numbers and concatenation for Strings.
 */

class JConditionalOp extends JTernaryExpression {

    /**
     * Construct an AST node for a conditional expression given its line number,
     * and the lhs and rhs operands.
     * 
     * @param line
     *            line in which the conditional expression occurs in the source
     *            file.
     * @param lhs
     *            the lhs operand.
     * @param rhs
     *            the rhs operand.
     */

    public JConditionalOp(int line, JExpression lhs, JExpression rhs1, JExpression rhs2) {
        super(line, "?", ":", lhs, rhs1, rhs2);
    }

    /**
     * Analysis involves first analyzing the operands. If this is a string
     * concatenation, we rewrite the subtree to make that explicit (and analyze
     * that). Otherwise we check the types of the addition operands and compute
     * the result type.
     * 
     * @param context
     *            context in which names are resolved.
     * @return the analyzed (and possibly rewritten) AST subtree.
     */

    public JExpression analyze(Context context) {
//        lhs = (JExpression) lhs.analyze(context);
//        rhs = (JExpression) rhs.analyze(context);
//        if (lhs.type() == Type.STRING || rhs.type() == Type.STRING) {
//            return (new JStringConcatenationOp(line, lhs, rhs))
//                    .analyze(context);
//        } else if (lhs.type() == Type.INT && rhs.type() == Type.INT) {
//            type = Type.INT;
//        } else {
//            type = Type.ANY;
//            JAST.compilationUnit.reportSemanticError(line(),
//                    "Invalid operand types for +");
//        }
        return this;
    }

    /**
     * Any string concatenation has been rewritten as a JStringConcatenationOp
     * (in analyze()), so code generation here involves simply generating code
     * for loading the operands onto the stack and then generating the
     * appropriate add instruction.
     * 
     * @param output
     *            the code emitter (basically an abstraction for producing the
     *            .class file).
     */

    public void codegen(CLEmitter output) {
//        if (type == Type.INT) {
//            lhs.codegen(output);
//            rhs.codegen(output);
//            output.addNoArgInstruction(IADD);
//        }
    }
    
//    public JExpression analyze(Context context) {
//        return this;
//    }
}
