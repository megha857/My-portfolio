
/*
 * Application Owned By: Uma Vadher, Prof. Kenneth Campbell. Co-coded by Megha Sharma
 * MainPanel.java
 *
 * Created on Oct 26, 2011, 11:48 PM
 * 
 */

package edu.umb.haspel.pituitaryHormoneDigestion;

public class SeqInformation {
  
  int firstNumber, lastNumber, subSeqLength, previousSeqLength, totalLengthUptoThisPoint;
  String subSeq;
  
  /**
   * @param newString
   * @param first
   * @param last
   */
  public void setValues(String newString) {
    subSeq = newString;
    subSeqLength = newString.length();
  }
  
  public int getFirst() {
    firstNumber = lastNumber + 1;
    return firstNumber;
  }
  
  public int getLast() {
    totalLengthUptoThisPoint = totalLengthUptoThisPoint + subSeqLength;
    lastNumber = totalLengthUptoThisPoint;
    return lastNumber;
  }
  
  public int getSubSeqLength() {
    return subSeqLength;
  }
}
