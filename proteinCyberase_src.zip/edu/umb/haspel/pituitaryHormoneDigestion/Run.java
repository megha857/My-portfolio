

/******************************************************************
  ******************************************************************
  * Program name: Protein Cyberase
  * Application Owned By: Uma Vadher, Prof. Kenneth Campbell. Co-coded by Megha Sharma
  * Place: University of Massachusetts Boston, Biology Department
  *        100 Morrissey Blvd, 
  *        Boston, MA 02125-3393
  * ALL RIGHTS RESERVED
  * ****************************************************************
  ***********************************************************************
  * Date: August 8, 2011                Coded By: UMA VADHER
  * File Name: Run.java
  * Source File: Run.java
  * 
  * Program Description:
  *      Protein Cyberase application is made to identify proteolytic
  * fragments of proteins in the presence of the lysosomal enzymes 
  * Cathepsins G, H, K and D, Trypsin, Chymotrypsin and CNBr
  * *****************************************************************
  * Software support:  On all platforms
  * Development environment: Windows, MacOX
  * *****************************************************************
  * Program Version: v3.6
  * *****************************************************************
  */

/*
 * Sample Sequence:
 *  MKTLQFFFLFCCWKAICCNSCELTNITIAIEKEECRFCISINTTWCAGYCYTRDLVYKDPARPKIQKTCTFKELVYETVRVPGCAHHADSLYTYPVATQCHCGKCDSDSTDCTVRGLGPSYCSFGEMKE
*/

package edu.umb.haspel.pituitaryHormoneDigestion;

public class Run {
  public static void main(String[] args) {
    MainPanel a = new MainPanel();
    a.setVisible(true);  
  }
}
