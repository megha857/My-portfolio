
/*
 * Application Owned By: Uma Vadher, Prof. Kenneth Campbell. Co-coded by Megha Sharma
 * MainPanel.java
 *
 * Created on Oct 26, 2011, 11:48 PM
 * 
 * 1) This version recifies error related to Chthepsin D 
 * 2) Also added Chatepsin B and S
 */

package edu.umb.bioinformatics.pituitaryHormoneDigestion;

import java.util.ArrayList;
import javax.swing.DefaultListModel;

public class EnzymeProcessing {
  
  private DefaultListModel<String> destListModel;
  private int minFragLength;
  private int maxFragLength;
  private String minLength;
  private String maxLength;
  private String error = "";
  private StringBuilder output;
  
  public DefaultListModel<String> getDestListModel() { return destListModel; }
  public int getMinFragLength() { return minFragLength; }
  public int getMaxFragLength() { return maxFragLength; }
  public String getMinLength() { return minLength; }
  public String getMaxLength() { return maxLength; }
  public String getError() { return error; }
  
  public void setDestListModel(DefaultListModel<String> val) { destListModel = val; }
  public void setMinFragLength(int val) { minFragLength = val; }
  public void setMaxFragLength(int val) { maxFragLength = val; }
  public void setMinLength(String val) { minLength = val; }
  public void setMaxLength(String val) { maxLength = val; }
  
  
  public String process(String primaryInput) {
    output = new StringBuilder();
    error = "";
    String input = "";
    EnzymeInformation ei = null;
    /* look for the first character in primary input */
    char ch = primaryInput.charAt(0); 
    if(ch == '>'){
      /* get the index of first line */  
      int j = primaryInput.indexOf("\n");
      /* ignore the first line start from the second one */  
      primaryInput = primaryInput.substring (j+1); 
    }
    for (int i = 0; i < primaryInput.length(); i++) {
      ch = primaryInput.charAt(i);
      if ((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z')) {
        input = input + Character.toString(ch);
      }
    }
    input = input.trim().toUpperCase();
        
    if (input.length() != 0) {
      output.append("Your input is: " + input);
      /* processed array */  
      ArrayList<String> inputArray = new ArrayList<String>();
      inputArray.add(input);
      
      /* the enzyme will be splited according to the specific rules that apply to it. */
      
      for (int i = 0; i < destListModel.getSize(); i++) {
        if (destListModel.getElementAt(i) == "Trypsin") {
          ei = new TrypsinEnzymeInformation();
          ei.applyAminoAcid(inputArray);
          output.append("\n\nAfter Trypsin: " + inputArray);
          provideInformation(inputArray);
        }
        
        if (destListModel.getElementAt(i) == "Chymotrypsin") {
          ei = new ChymoTrypsinEnzymeInformation();
          ei.applyAminoAcid(inputArray);
          output.append("\n\nAfter Chymotrypsin: " + inputArray);
          provideInformation(inputArray);
        }
        if (destListModel.getElementAt(i) == "Cathepsin A") {
          ei = new CathepsinAEnzymeInformation();
          ei.applyAminoAcid(inputArray);  
          output.append("\n\nAfter Cathepsin A: " + inputArray);
          provideInformation(inputArray);
        }
        if (destListModel.getElementAt(i) == "Cathepsin B") {
          ei = new CathepsinBEnzymeInformation();
          ei.applyAminoAcid(inputArray);  
          output.append("\n\nAfter Cathepsin B: " + inputArray);
          provideInformation(inputArray);
        }
        if (destListModel.getElementAt(i) == "Cathepsin C") {
          ei = new CathepsinCEnzymeInformation();
          ei.applyAminoAcid(inputArray);  
          output.append("\n\nAfter Cathepsin C: " + inputArray);
          provideInformation(inputArray);
        }
        if (destListModel.getElementAt(i) == "Cathepsin D") {
          ei = new CathepsinDEnzymeInformation();
          ei.applyAminoAcid(inputArray);  
          output.append("\n\nAfter Cathepsin D: " + inputArray);
          provideInformation(inputArray);
        }
        
        if (destListModel.getElementAt(i) == "Cathepsin G") {
          ei = new CathepsinGEnzymeInformation();
          ei.applyAminoAcid(inputArray);  
          output.append("\n\nAfter Cathepsin G: " + inputArray);
          provideInformation(inputArray);
        }
        
        if (destListModel.getElementAt(i) == "Cathepsin H") {
          ei = new CathepsinHEnzymeInformation();
          ei.applyAminoAcid(inputArray);
          output.append("\n\nAfter Cathepsin H: " + inputArray);
          provideInformation(inputArray);
        }
        
        if (destListModel.getElementAt(i) == "Cathepsin K") {
          ei = new CathepsinKEnzymeInformation();
          ei.applyAminoAcid(inputArray); 
          output.append("\n\nAfter Cathepsin K: " + inputArray);
          provideInformation(inputArray);
        }
        
        if (destListModel.getElementAt(i) == "Cathepsin L") {
          ei = new CathepsinLEnzymeInformation();
          ei.applyAminoAcid(inputArray);
          output.append("\n\nAfter Cathepsin L: " + inputArray);
          provideInformation(inputArray);
        }
        
        if (destListModel.getElementAt(i) == "Cathepsin S") {
          ei = new CathepsinSEnzymeInformation();
          ei.applyAminoAcid(inputArray);
          output.append("\n\nAfter Cathepsin S: " + inputArray);
          provideInformation(inputArray);
        }
        
        if (destListModel.getElementAt(i) == "CNBr") {
          ei = new CNBREnzymeInformation();
          ei.applyAminoAcid(inputArray);
          output.append("\n\nAfter CNBr: " + inputArray);
          provideInformation(inputArray);
        }
        
      }
    } else {
      output.append("Please provide Protein sequence at Step 1:");
    }
    
    return output.toString();
  }
  
  private void provideInformation(ArrayList<String> inputArray) {
    int first = 0, last = 0, seqLength = 0;
    String newString;
    SeqInformation s = new SeqInformation();
    
    for (int i = 0; i < inputArray.size(); i++) {
      newString = inputArray.get(i);
      s.setValues(newString);
      first = s.getFirst();
      last = s.getLast();
      seqLength = s.getSubSeqLength();
      setMinMaxValues();
      //   System.out.println("Minmax are " + minFragLength + " " + maxFragLength);
      if ((minFragLength <= seqLength) && (seqLength <= maxFragLength)) {
        output.append("\nSub-Sequence:  " + newString + " \t Starts at: " + first + "\t Ends at: " +
                      last + "\tLength: " + seqLength);
      }
    }
  }
  
  private void setMinMaxValues()
  {
    boolean minValid = minLength.length() != 0;
    boolean maxValid = maxLength.length() != 0;
    
    if (minValid) {
      try {
        minFragLength = Integer.parseInt(minLength);
      } catch (Exception ex) {
        error = "Invalid Min Length value, Please provide a valid number in next run";
        minLength = "";
        maxLength = "";
        return;
      }
    }
    if(maxValid){
      try {
        maxFragLength = Integer.parseInt(maxLength);
      } catch (Exception x) {
        error = "Invalid Max Length value, Please provide a valid number in next run";
        minLength = "";
        maxLength = "";
        return;
      }
    }
    try {
      if (minFragLength > maxFragLength) {
      }
    } catch (Exception exc) {
    }
  }
}
