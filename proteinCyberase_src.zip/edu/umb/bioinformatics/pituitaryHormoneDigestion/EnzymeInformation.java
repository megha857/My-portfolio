
/*
 * Application Owned By: Uma Vadher, Prof. Kenneth Campbell. Co-coded by Megha Sharma
 * MainPanel.java
 *
 * Created on Oct 26, 2011, 11:48 PM
 * 
 * 1) This version recifies error related to Chthepsin D 
 * 2) Also added Chatepsin B and S
 */

package edu.umb.bioinformatics.pituitaryHormoneDigestion;

import java.util.ArrayList;

/* BASE */
public abstract class EnzymeInformation {
  
  public abstract ArrayList<String> addValueToArray(ArrayList<String> aftercutArray, String newString);
  
  public void applyAminoAcid( ArrayList<String> inputArray)
  {
    String newString;
    ArrayList<String> aftercutArray = new ArrayList<String>();
    
    /* Split the sequence at a given character by taking the string and by using addValueToArray() method */
    for (int i = 0; i < inputArray.size(); i++) {
      newString = inputArray.get(i);
      /* The function will be overridden by new methods from specific enzymes */
      aftercutArray = addValueToArray(aftercutArray, newString);
    }
    
    /* To reuse the same ArrayList, first empty inputArray and then copy the content 
     of aftercutArray. Lastly, empty aftercutArray. */
    inputArray.clear();
    
    for (int i = 0; i < aftercutArray.size(); i++) {
      String s = aftercutArray.get(i);
      inputArray.add(s);
    }
    
    aftercutArray.clear(); 
  }
}


/* TRYPSIN */
class TrypsinEnzymeInformation extends EnzymeInformation {
  public ArrayList<String> addValueToArray(ArrayList<String> cutArray, String newString)
  {
    String input = newString;
    /* 0: current position */
    int cutInt = 0; 
    
    /* If character is equal to the given character, that substring will be added to 
     Arraylist. Then, the ArrayList will be returned. */
    try {
      int l = input.length();
      for (int i = 0; i < l; i++) {
        
        /* Rule: if character is either R or K and if the character is not the last character of sequence */
        if ((input.charAt(i) == 'K' ||input.charAt(i) == 'R')
              && (i != l - 1)) {
          cutArray.add(input.substring(cutInt, i + 1));
          cutInt = i + 1;
        }
      }
    } catch (NullPointerException npe) {}
    cutArray.add(input.substring(cutInt, input.length()));
    return cutArray;
  }    
}


/* CHYMOTRPSIN */
class ChymoTrypsinEnzymeInformation extends EnzymeInformation {
  public ArrayList<String> addValueToArray(ArrayList<String> cutArray, String newString)
  {
    String input = newString;
    /* 0: current position*/ 
    int cutInt = 0; 
    
    /* If character is equal to given character, that substring will be added to the Arraylist.
     * Then the ArrayList will be returned.*/
    try {
      int l = input.length();
      String s="FYWLIV";
      for (int i = 0; i < l-1; i++) {
        /*  Rule: If character is equal to a character in FYWLIV,
         *  and if the character is not before the letter P  */
        
        if ((s.indexOf(input.charAt(i)) >= 0)
              && (input.charAt(i+1) != 'P')) {
          cutArray.add(input.substring(cutInt, i + 1));
          cutInt = i + 1;
        }
      }
    } catch (NullPointerException npe) {}
    cutArray.add(input.substring(cutInt, input.length()));
    return cutArray;
  }
}


/* CNBR */
class CNBREnzymeInformation extends EnzymeInformation {
  public ArrayList<String> addValueToArray(ArrayList<String> cutArray, String newString)
  {
    String input = newString;
    /* 0: current position */
    int cutInt = 0;
    /* If character is equal to given character, then the substring will be added to Arraylist.
     *  Then the ArrayList will be returned. */
    try {
      int l = input.length();
      for (int i = 0; i < l; i++) {
        /* Rule: Split after M */
        if (input.charAt(i) == 'M') {
          cutArray.add(input.substring(cutInt, i + 1));
          cutInt = i + 1;
        }
      }
    } catch (NullPointerException npe) {}
    cutArray.add(input.substring(cutInt, input.length()));
    return cutArray;
  }
}


/* A - CATHEPSIN */
class CathepsinAEnzymeInformation extends EnzymeInformation {
  public ArrayList<String> addValueToArray(ArrayList<String> cutArray,  String newString)
  {
    String input = newString;
    /* 0: current position */ 
    int cutInt = 0;
    
    /* If character is equal to given character, then the substring will be added to 
     the Arraylist and then the ArrayList will be returned.*/
    try {
      int l = input.length();
      
      /* Rule: If there's an F in the C-terminus, split after A,V,L,I.P,W,F or M */
      
      if ((input.charAt(l-1) == 'A' || input.charAt(l-1) == 'V' || input.charAt(l-1) == 'L' ||
           input.charAt(l-1) == 'I' || input.charAt(l-1) == 'P' || input.charAt(l-1) == 'W' ||
           input.charAt(l-1) == 'F' || input.charAt(l-1) == 'M') &&
          input.charAt(l-2) == 'F') {
        cutArray.add(input.substring(cutInt, l-1));
        cutInt=l-1;
      }
    }
    catch (NullPointerException npe) {}
    cutArray.add(input.substring(cutInt, input.length()));
    return cutArray;
  }
}


/* B - CATHEPSIN */
class CathepsinBEnzymeInformation extends EnzymeInformation {
  public ArrayList<String> addValueToArray(ArrayList<String> cutArray, String newString)
  {
    String input = newString;
    /* 0: current position */ 
    int cutInt = 0; 
    
    /* If character is equal to given character, then the substring will be added to Arraylist.
     *  Then the ArrayList will be returned.*/
    try {
      int l = input.length();
      for (int i = 0; i < l-3; i++) {
        // Rule: Cut after K,R or G in P1 and G in P3'
        if ((input.charAt(i) == 'R' || input.charAt(i) == 'K' || input.charAt(i) == 'G') && 
            input.charAt(i+3) == 'G') {
          cutArray.add(input.substring(cutInt, i + 1));
          cutInt = i + 1; 
        }
      }
    } catch (NullPointerException npe) {}
    cutArray.add(input.substring(cutInt, input.length()));
    return cutArray;
  }
}


/* C - CATHEPSIN */
class CathepsinCEnzymeInformation extends EnzymeInformation {
  public ArrayList<String> addValueToArray(ArrayList<String> cutArray, String newString)
  {
    String input = newString;
    /* 0: current position */ 
    int cutInt = 0; 
    /* If character is equal to given character, then the substring will be added to Arraylist.
     *  Then the ArrayList will be returned.*/
    try {
      int l = input.length();
      for (int i = 1; i < l-4; i++) {
        /* Rule: Cut E,S in P1, I in P'1 and GG in P'3,4 */
        if ((input.charAt(i-1) != 'K' && input.charAt(i-1) != 'R' && input.charAt(i-1) != 'P') && 
            (input.charAt(i) == 'E' || input.charAt(i) == 'S') &&
            input.charAt(i+1) == 'I' && input.charAt(i+3) == 'G' && input.charAt(i+4) == 'G') {
          cutArray.add(input.substring(cutInt, i + 1));
          cutInt = i + 1; 
        }
      }
    } catch (NullPointerException npe) {}
    cutArray.add(input.substring(cutInt, input.length()));
    return cutArray;
  }
}


/* D - CATHEPSIN */
class CathepsinDEnzymeInformation extends EnzymeInformation {
  public ArrayList<String> addValueToArray(ArrayList<String> cutArray, String newString)
  {
    String input = newString;
    /* 0: current position */
    int cutInt = 0; 
    
    /* If character is equal to given character, then the substring will be added to Arraylist.
     *  Then the ArrayList will be returned.*/
    try {
      int l = input.length();
      String P1="ALWFMY";
      String P1Prime = "AVLIWFMY";
      for (int i = 1; i < l-3; i++) {
        
        /* Rule: 
         * K must not be at position P2
         * A, L, W, F, M, and Y must be at position P1
         * A, V, L, I, W, F, M, and Y must be at position P1'. */
        
        if (input.charAt(i-1) != 'K' &&
            P1.indexOf(input.charAt(i)) >= 0 &&
            P1Prime.indexOf(input.charAt(i+1)) >= 0 ) {
          cutArray.add(input.substring(cutInt, i + 1));
          cutInt = i + 1; 
        }
      }
    } catch (NullPointerException npe) {}
    cutArray.add(input.substring(cutInt, input.length()));
    return cutArray;
  }
}

/* G - CATHEPSIN */
class CathepsinGEnzymeInformation extends EnzymeInformation {
  public ArrayList<String> addValueToArray(ArrayList<String> cutArray, String newString)
  {
    String input = newString;
    /* 0: current position */
    int cutInt = 0;
    
    /* If character is equal to given character, then the substring will be added to Arraylist.
     *  Then the ArrayList will be returned.*/
    try {
      int l = input.length();
      String s= "LYFMQNH";
      for (int i = 2; i < l-4; i++) {
        /*  Rule: if character is equal to a character in LYFMWQNH */
        if (input.charAt(i-2) == 'V'&& input.charAt(i+1) == 'S' &&
            input.charAt(i+4) == 'V' &&
            s.indexOf(input.charAt(i)) >= 0) {
          cutArray.add(input.substring(cutInt, i + 1));
          cutInt = i + 1;
        }
      }
    } catch (NullPointerException npe) {}
    cutArray.add(input.substring(cutInt, input.length()));
    return cutArray;
  }
}


/* SE - CATHEPSIN */
class CathepsinSEnzymeInformation extends EnzymeInformation {
  public ArrayList<String> addValueToArray(ArrayList<String> cutArray, String newString)
  {
    String input = newString;
    /* 0: current position */
    int cutInt = 0; 
    /* If character is equal to given character, then the substring will be added to Arraylist.
     *  Then the ArrayList will be returned. */
    try {
      int l = input.length();
      String s="MFLWYV";
      for (int i = 0; i < l-2; i++) {
        
        /* Rule: If character at position P2 is equal to a character in MFLWYV */
        
        if (s.indexOf(input.charAt(i)) >= 0) {
          cutArray.add(input.substring(cutInt, i + 2));
          cutInt = i + 2;
        }
      }
    } catch (NullPointerException npe) {}
    cutArray.add(input.substring(cutInt, input.length()));
    return cutArray;
  }
}


/* LE - CATHEPSIN */
class CathepsinLEnzymeInformation extends EnzymeInformation {
  public ArrayList<String> addValueToArray(ArrayList<String> cutArray, String newString)
  {
    String input = newString;
    /* 0: current position */
    int cutInt = 0; 
    
    /* If character is equal to given character, then the substring will be added to Arraylist.
     *  Then the ArrayList will be returned. */
    try {
      int l = input.length();
      String s="IMFLWYV";
      for (int i = 0; i < l-2; i++) {
        /*  Rule: If character is equal to a character in IMFLWYV and it is at position P2
         * and if V is not at position P1' */
        if (s.indexOf(input.charAt(i)) >= 0 && input.charAt(i+2)!='P' && input.charAt(i+2)!='C') {
          cutArray.add(input.substring(cutInt, i + 2));
          cutInt = i + 2;
        }
      }
    } catch (NullPointerException npe) {}
    cutArray.add(input.substring(cutInt, input.length()));
    return cutArray;
  }
}


/* KE - CATHEPSIN */
class CathepsinKEnzymeInformation extends EnzymeInformation {
  public ArrayList<String> addValueToArray(ArrayList<String> cutArray, String newString)
  {
    String input = newString;
    /* 0: current position */
    int cutInt = 0; 
    
    /* If character is equal to given character, then the substring will be added to Arraylist.
     *  Then the ArrayList will be returned. */
    try {
      int l = input.length();
      String s="LPVMF";
      for (int i = 1; i < l; i++) {
        /* Rule: if character is equal to L,M,F and is at position P2 */
        if ((input.charAt(i) == 'E'|| input.charAt(i) == 'A') &&
            s.indexOf(input.charAt(i-1)) >= 0) {
          cutArray.add(input.substring(cutInt, i + 1));
          cutInt = i + 1;
        }
      }
    } catch (NullPointerException npe) {}
    cutArray.add(input.substring(cutInt, input.length()));
    return cutArray;
  }
}


/* HE - CATHEPSIN */
class CathepsinHEnzymeInformation extends EnzymeInformation {
  public ArrayList<String> addValueToArray(ArrayList<String> cutArray, String newString)
  {
    String input = newString;
    /* 0: current position */
    int cutInt = 0;
    /* If character is equal to given character, then the substring will be added to Arraylist.
     *  Then the ArrayList will be returned. */
    try {
      int l = input.length();
      for (int i = 0; i < l-2; i++) {
        /* Rule: If character is equal to R and if the character at position p'2 is P */
        if (input.charAt(i) == 'R' && 
            (input.charAt(i+2) == 'P' || input.charAt(i+2) == 'E')) {
          cutArray.add(input.substring(cutInt, i + 1));
          cutInt = i + 1;
        }
      }
    } catch (NullPointerException npe) {}
    cutArray.add(input.substring(cutInt, input.length()));
    return cutArray;
  }
}

