
Protein splicer - source code (Java)
by Megha Sharma

This is a protein splicer, written to aid in bioinformatics research.

This java source code is designed to be compiled within it's folder path (for packaging) and run from the "Run" class.
