
Space simulation - source code (C++)
by Megha Sharma

This is a 3d space simulation.  My contribution to this project was the user interface.

This project is broken up into two parts:

GravitySimulator is the simulation.  It can be run with make.  It depends on libraries already embedded in the code.

GravityUI is the user interface.  It depends upon QT4.  The code is setup to be run from QTCreator, along with a project file: "GravSimUI2.pro".
